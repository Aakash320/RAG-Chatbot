import React from "react";
import { Bubble } from "@ant-design/x";
import { Avatar, Empty } from "antd";
import { UserOutlined, RobotOutlined } from "@ant-design/icons";

const rolesConfig = {
  user: {
    placement: "end",
    avatar: <Avatar icon={<UserOutlined />} style={{ background: "#6083b4ff" }} />,
  },
  assistant: {
    placement: "start",
    avatar: <Avatar icon={<RobotOutlined />} style={{ background: "#83b06dff" }} />,
  },
};

/**
 * ChatWindow renders the scrollable list of chat bubbles.
 *
 * Expected `messages` shape:
 * [{ key: string, role: "user" | "assistant", content: string, loading?: boolean }]
 */
export default function ChatWindow({ messages }) {
  if (!messages || messages.length === 0) {
    return (
      <div
        style={{
          height: "100%",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <Empty
          image={Empty.PRESENTED_IMAGE_SIMPLE} 
          description="Say hello to start the conversation" 
        />
      </div>
    );
  }

  return (
    <Bubble.List
      style={{ height: "100%" }}
      role={rolesConfig}
      items={messages.map((message) => ({
        key: message.key,
        role: message.role,
        content: message.content,
        loading: message.loading,
      }))}
    />
  );
}