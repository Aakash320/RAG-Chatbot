import React, { useState } from "react";
import { Card } from "antd";
import ChatWindow from "../components/chat/ChatWindow";
import ChatSender from "../components/chat/ChatSender";
import { Typography } from "antd";
import { sendChatMessage } from "../apis/chatApi";

const {Title} = Typography

let messageCounter = 0;
const nextKey = () => `msg-${Date.now()}-${messageCounter++}`;

export default function ChatPage() {
  const [messages, setMessages] = useState([]);
  const [isSending, setIsSending] = useState(false);

  const handleSend = async (text) => {
    const userMessage = { key: nextKey(), role: "user", content: text };
    const loadingMessage = {
      key: nextKey(),
      role: "assistant",
      content: "Thinking...",
      loading: true,
    };

    setMessages((prev) => [...prev, userMessage, loadingMessage]);
    setIsSending(true);

    try {
      // TODO: sendChatMessage() in apis/chatApi.js is currently a placeholder for POST /chat.
      const reply = await sendChatMessage(text);
      // const reply = {
      //   id: `placeholder-${Date.now()}`,
      //   role: "assistant",
      //   content: "This is a placeholder AI response. Connect the real chat API to replace this.",
      //   createdAt: new Date().toISOString(),
      // }

      setMessages((prev) =>
        prev.map((message) =>
          message.key === loadingMessage.key
            ? { key: reply.id ?? nextKey(), role: "assistant", content: reply.content }
            : message
        )
      );
    } catch (error) {
      setMessages((prev) =>
        prev.map((message) =>
          message.key === loadingMessage.key
            ? {
                ...message,
                loading: false,
                content: "Something went wrong getting a response. Please try again.",
              }
            : message
        )
      );
    } finally {
      setIsSending(false);
    }
  };

  return (
    <Card
      // style={{ height: "calc(100vh - 128px)" }}
      style={{ height: "calc(100vh - 18px)" }}
      styles={{
        body: {
          height: "100%",
          display: "flex",
          flexDirection: "column",
          gap: 16,
          padding: 16,
        },
      }}
    >
      <Title level={3}>RAG Chatbot</Title>
      <div style={{ flex: 1, overflow: "auto" }}>
        <ChatWindow messages={messages} />
      </div>
      <ChatSender onSend={handleSend} loading={isSending} />
    </Card>
  );
}
