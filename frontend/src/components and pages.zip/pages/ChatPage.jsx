import { useState } from "react";
import { Flex, Typography } from "antd";

import ChatBubble from "../components/chat/ChatBubble";
import ChatSender from "../components/chat/ChatSender";

const { Title } = Typography;

export default function ChatPage() {
  const [messages, setMessages] = useState([]);
  const [loading, setLoading] = useState(false);

  async function handleSend(text) {
    // Show user's message immediately
    setMessages((prev) => [
      ...prev,
      {
        role: "user",
        content: text,
      },
    ]);

    setLoading(true);

    try {
      // const response = await axios.post("/chat", { message: text });

      // Dummy response
      const response = {
        data: {
          answer: "This is the AI response.",
        },
      };

      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          content: response.data.answer,
        },
      ]);
    } finally {
      setLoading(false);
    }
  }

  return (
    <Flex
      vertical
      style={{
        // flex: 1,
        // display: "flex",
        // flexDirection: "column",
        padding: 24,
        // overflow: "hidden",
        // boxSizing: "border-box",
      }}
    >
      <Title
        level={3}
        style={{
          margin: 0,
          marginBottom: 16,
        }}
      >
        RAG Chatbot
      </Title>

      <Flex
        vertical
        gap={12}
        style={{
          flex: 1,
          overflowY: "auto",
          minHeight: 0,
          paddingBottom: 12,
        }}
      >
        {messages.map((message, index) => (
          <ChatBubble
            key={index}
            role={message.role}
            content={message.content}
          />
        ))}
      </Flex>

      <ChatSender
        onSend={handleSend}
        loading={loading}
      />
    </Flex>
  );
}