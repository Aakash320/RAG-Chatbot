import {Bubble} from "@ant-design/x"
import { Flex } from "antd"

export default function ChatBubble({content, role}){
    const isUser = role === "user"
    return(
        <Flex justify = {isUser ? "flex-end" : "flex-start"}>
            <Bubble
                placement={isUser ? "end" : "start"}
                content={content}
            />
        </Flex>
    );
}