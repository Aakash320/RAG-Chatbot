import { Sender } from "@ant-design/x";
import { useState } from "react";

export default function ChatSender({onSend, loading}){
    const[value, setValue] = useState("");

    const handleSubmit = () => {
        const text = value.trim();
        if(!text) return;
        onSend(text);
        setValue("");
    }

    return(
        <Sender
            value={value}
            onChange={setValue}
            onSubmit={handleSubmit}
            loading={loading}
            placeholder="Enter message..."
        />
    );
}