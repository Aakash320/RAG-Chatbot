import { useState } from "react";
import { Flex, Typography } from "antd";
import { Bubble, Sender } from "@ant-design/x";

const { Title } = Typography;

export default function Chat() {
  const [messages, setMessages] = useState([]);
  const [value, setValue] = useState("");

  const handleSend = () => {
    const text = value.trim();

    if (!text) return;

    setMessages((prev) => [
      ...prev,
      {
        id: Date.now(),
        content: text,
      },
    ]);

    setValue("");
  };

  return (
    <Flex
      vertical
      style={{
        height: "100vh",
        padding: 24,
      }}
    >
      <Title level={3}>RAG Chatbot</Title>

      {/* Chat Area */}
      <Flex
        vertical
        gap={12}
        style={{
          flex: 1,
          overflowY: "auto",
          marginBottom: 20,
        }}
      >
        {messages.map((message) => (
          <Bubble
            key={message.id}
            content={message.content}
            placement="end"
          />
        ))}
      </Flex>

      {/* Sender */}
      <Sender
        value={value}
        onChange={setValue}
        onSubmit={handleSend}
        placeholder="Type a message..."
      />
    </Flex>
  );
}