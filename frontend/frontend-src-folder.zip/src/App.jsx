import React from "react";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { ConfigProvider } from "antd";
import { AuthProvider } from "./context/AuthContext";
import ProtectedRoute from "./components/auth/ProtectedRoute";
import AppLayout from "./layout/AppLayout";
import ChatPage from "./pages/ChatPage";
import DocumentPage from "./pages/DocumentPage";
import LoginPage from "./pages/LoginPage";
import RegisterPage from "./pages/RegisterPage";
import { ROUTES } from "./constants/routes";

export default function App() {
  return (
    <ConfigProvider
      theme={{
        token: {
          colorPrimary: "#1677ff",
          borderRadius: 8,
        },
      }}
    >
      <BrowserRouter>
        <AuthProvider>
          <Routes>
            <Route path={ROUTES.LOGIN} element={<LoginPage />} />
            <Route path={ROUTES.REGISTER} element={<RegisterPage />} />

            <Route element={<ProtectedRoute />}>
              <Route path="/" element={<Navigate to={ROUTES.CHAT} replace />} />
              <Route
                path={ROUTES.CHAT}
                element={
                  <AppLayout>
                    <ChatPage />
                  </AppLayout>
                }
              />
              <Route
                path={`${ROUTES.CHAT}/:sessionId`}
                element={
                  <AppLayout>
                    <ChatPage />
                  </AppLayout>
                }
              />
              <Route
                path={ROUTES.DOCUMENTS}
                element={
                  <AppLayout>
                    <DocumentPage />
                  </AppLayout>
                }
              />
              <Route path="*" element={<Navigate to={ROUTES.CHAT} replace />} />
            </Route>
          </Routes>
        </AuthProvider>
      </BrowserRouter>
    </ConfigProvider>
  );
}