export const ROUTES = {
  CHAT: "/chat",
  DOCUMENTS: "/documents",
  LOGIN: "/login",
  REGISTER: "/register",
};

export const NAV_ITEMS = [
  { key: ROUTES.CHAT, label: "Chat" },
  { key: ROUTES.DOCUMENTS, label: "Documents" },
];
