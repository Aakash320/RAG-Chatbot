import React, { forwardRef, useEffect, useImperativeHandle, useState } from "react";
import { Button, Empty, Flex, List, Popconfirm, Spin, Tooltip, Typography } from "antd";
import { DeleteOutlined, PlusOutlined } from "@ant-design/icons";
import { listSessions, deleteSession } from "../../apis/chatSessionApi";

const { Text } = Typography;

/**
 * Left-hand panel listing the current user's chat sessions.
 * Exposes `refresh()` via ref so ChatPage can re-fetch the list after a
 * new session is created or a session's recency/title changes.
 */
const ChatHistorySidebar = forwardRef(function ChatHistorySidebar(
  { activeSessionId, onSelect, onNewChat },
  ref
) {
  const [sessions, setSessions] = useState([]);
  const [loading, setLoading] = useState(true);

  const fetchSessions = async () => {
    try {
      const data = await listSessions();
      setSessions(data);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSessions();
  }, []);

  useImperativeHandle(ref, () => ({ refresh: fetchSessions }));

  const handleDelete = async (sessionId) => {
    await deleteSession(sessionId);
    setSessions((prev) => prev.filter((s) => s.id !== sessionId));
    if (sessionId === activeSessionId) onNewChat();
  };

  return (
    <Flex vertical style={{ width: 260, borderRight: "1px solid #f0f0f0", height: "100%" }}>
      <div style={{ padding: 12 }}>
        <Button icon={<PlusOutlined />} block onClick={onNewChat}>
          New chat
        </Button>
      </div>

      <div style={{ flex: 1, overflow: "auto", padding: "0 8px" }}>
        {loading ? (
          <Flex justify="center" style={{ padding: 24 }}>
            <Spin />
          </Flex>
        ) : sessions.length === 0 ? (
          <Empty
            image={Empty.PRESENTED_IMAGE_SIMPLE}
            description="No conversations yet"
            style={{ marginTop: 24 }}
          />
        ) : (
          <List
            dataSource={sessions}
            renderItem={(session) => (
              <List.Item
                key={session.id}
                onClick={() => onSelect(session.id)}
                style={{
                  cursor: "pointer",
                  padding: "8px 10px",
                  borderRadius: 8,
                  background: session.id === activeSessionId ? "#e6f4ff" : "transparent",
                  border: "none",
                }}
              >
                <Flex justify="space-between" align="center" style={{ width: "100%" }}>
                  <Text ellipsis style={{ maxWidth: 180 }}>
                    {session.title || "New conversation"}
                  </Text>
                  <Popconfirm
                    title="Delete this conversation?"
                    onConfirm={(e) => {
                      e?.stopPropagation();
                      handleDelete(session.id);
                    }}
                    onCancel={(e) => e?.stopPropagation()}
                  >
                    <Tooltip title="Delete">
                      <DeleteOutlined onClick={(e) => e.stopPropagation()} style={{ opacity: 0.5 }} />
                    </Tooltip>
                  </Popconfirm>
                </Flex>
              </List.Item>
            )}
          />
        )}
      </div>
    </Flex>
  );
});

export default ChatHistorySidebar;